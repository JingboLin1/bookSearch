package com.example.booksearch;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import okhttp3.*;

public class MainActivity extends AppCompatActivity {

    private EditText etSearch;
    private TextView tvResult;
    private OkHttpClient client = new OkHttpClient();
    private Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind views
        etSearch = findViewById(R.id.et_search);
        tvResult = findViewById(R.id.tv_result);
        Button btnSearch = findViewById(R.id.btn_search);

        // Button click event
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = etSearch.getText().toString();
                if (query.isEmpty()) {
                    Toast.makeText(MainActivity.this, "请输入书名", Toast.LENGTH_SHORT).show();
                } else {
                    searchBooks(query);
                }
            }
        });
    }

    private void searchBooks(String query) {
        // Construct request URL (replace with your actual backend address)
        String url = "https://effective-guide-7v54vp597xpr2xpgg-8080.app.github.dev/api/books?q=" + query;

        // Create request object
        Request request = new Request.Builder()
                .url(url)
                .build();

        // Send asynchronous requestSend asynchronous request
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Request Fail: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String json = response.body().string();
                    Book book = gson.fromJson(json, Book.class);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvResult.setText("Book Name：" + book.getTitle() + "\nAuthor：" + book.getAuthor() + "\nYear：" + book.getYear());
                        }
                    });
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Error code: " + response.code(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    // Define data model class
    public static class Book {
        private String title;
        private String author;
        private int year;

        public String getTitle() { return title; }
        public String getAuthor() { return author; }
        public int getYear() { return year; }
    }
}
}
}