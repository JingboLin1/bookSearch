package com.bookSearch.servlets;

import com.bookSearch.utils.MongoLogger;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import sun.net.www.protocol.http.HttpURLConnection;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Date;

@WebServlet("/api/books")
public class BookServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        long startTime = System.currentTimeMillis();
        // 1. Get user Input
        String query = request.getParameter("q");
        if (query == null || query.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing 'q' parameter");
            return;
        }

        // 2. Open Library API
        String apiResponse = callOpenLibraryAPI(query);

        // 3. Parse and extract key data
        JsonObject bookData = parseApiResponse(apiResponse);

        // 4. Log to MongoDB
        logRequestToMongo(request, bookData);

        // 5. Return simplified JSON response
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(bookData.toString());

        long apiLatency = System.currentTimeMillis() - startTime;
        logToMongoDB(request, query, bookData, apiLatency);
    }

    private String callOpenLibraryAPI(String query) throws IOException {
        String encodedQuery = URLEncoder.encode(query, "UTF-8");
        URL url = new URL("https://openlibrary.org/search.json?q=" + encodedQuery);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        StringBuilder response = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
        }
        return response.toString();
    }

    private JsonObject parseApiResponse(String apiResponse) {
        JsonObject json = JsonParser.parseString(apiResponse).getAsJsonObject();
        JsonObject firstBook = json.getAsJsonArray("docs").get(0).getAsJsonObject();

        // Extract key fields
        JsonObject result = new JsonObject();
        result.addProperty("title", firstBook.get("title").getAsString());
        result.addProperty("author", firstBook.getAsJsonArray("author_name").get(0).getAsString());
        result.addProperty("year", firstBook.get("first_publish_year").getAsInt());
        return result;
    }

    private void logRequestToMongo(HttpServletRequest request, JsonObject bookData) {
        // See the MongoLogger class in the next step
        String title = bookData.get("title").getAsString();
        MongoLogger.logRequest(request, title);
    }

    private static final String CONN_STRING = "mongodb+srv://gzz200200:E8UPIDbTcjnrxKKY@cluster0.gyqyv.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"; // 替换为你的 Atlas 连接字符串
    //    private static final String DB_NAME = "book_logs";
    private static final String DB_NAME = "testDB";
    //    private static final String COLLECTION_NAME = "requests";
    private static final String COLLECTION_NAME = "searches";

    private void logToMongoDB(HttpServletRequest request, String query, JsonObject bookData, long apiLatency) {
        try (MongoClient client = MongoClients.create(CONN_STRING)) {
            MongoCollection<Document> logs = client.getDatabase(DB_NAME).getCollection(COLLECTION_NAME);

            // Build log document
            Document logEntry = new Document()
                    .append("timestamp", new Date())
                    .append("clientIp", request.getRemoteAddr())
                    .append("userAgent", request.getHeader("User-Agent"))
                    .append("searchTerm", query)
                    .append("apiResponseTime", apiLatency + "ms")
                    .append("bookTitle", bookData.get("title").getAsString())
                    .append("httpStatus", HttpServletResponse.SC_OK);

            logs.insertOne(logEntry); // Insert into database
        } catch (Exception e) {
            System.err.println("MongoDB record Fail: " + e.getMessage());
        }
    }
}
