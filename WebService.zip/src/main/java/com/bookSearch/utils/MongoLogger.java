package com.bookSearch.utils;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
public class MongoLogger {
    private static final String CONN_STRING = "mongodb+srv://gzz200200:E8UPIDbTcjnrxKKY@cluster0.gyqyv.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"; // 替换为你的 Atlas 连接字符串
//    private static final String DB_NAME = "book_logs";
    private static final String DB_NAME = "testDB";
//    private static final String COLLECTION_NAME = "requests";
    private static final String COLLECTION_NAME = "searches";

    public static void logRequest(HttpServletRequest request, String title) {
        try (MongoClient client = MongoClients.create(CONN_STRING)) {
            MongoCollection<Document> logs = client.getDatabase(DB_NAME).getCollection(COLLECTION_NAME);

            Document logEntry = new Document()
                .append("timestamp", new Date())
                .append("userIp", request.getRemoteAddr())
                .append("userAgent", request.getHeader("User-Agent"))
                .append("searchTerm", request.getParameter("q"))
                .append("bookTitle", title)
                .append("status", "success");

            logs.insertOne(logEntry);
        }
    }
}